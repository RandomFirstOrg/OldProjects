let hr = [
    {
        name : "Hariom",age : 20,sname : "Dhakad"},
    {
        name : "Hariom",age : 20,sname : "Dhakad"},
    {
        name : "Hariom", age : 20,sname : "Dhakad"},
]
for(i=0; i<hr.length; i++)
{
    hr.filter()
}